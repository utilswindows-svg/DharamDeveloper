const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    dialect: 'mysql',
    logging: true,
    pool: { max: 10, min: 0, acquire: 30000, idle: 10000 },
  }
);
const connectDB = async () => { await sequelize.authenticate(); console.log('✅ MySQL connected'); };
module.exports = { sequelize, connectDB };
